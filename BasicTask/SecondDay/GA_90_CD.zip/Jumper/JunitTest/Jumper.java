package test;
/*********************************************************************
 * Jumper.java  Version 1.00  <Thu Jul  4 16:28:24 2013>
 * By Group 90
 * SUN YAT-SEN UNIVERSITY, GZ 510006, P. R. China
 ********************************************************************/

import java.awt.Color;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Flower;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class Jumper extends Actor {
	/**
	 * Constructs a red jumper.
	 */
	public Jumper() {
		setColor(Color.RED);
	}

	/**
	 * Constructs a jumper of a given color.
	 * 
	 * @param bugColor, Color
	 *            the color for this jumper
	 */
	public Jumper(Color jumperColor) {
		setColor(jumperColor);
	}

	/**
	 * Moves if it can move, turns otherwise.
	 */
	@Override
	public void act() {
		int count = canMove();
		if (count > 0) {
			move(count);
		} else {
			turn();
		}
	}

	/**
	 * Turns the jumper 45 degrees to the right without changing its location.
	 */
	public void turn() {
		setDirection(getDirection() + Location.HALF_RIGHT);
	}


    
	/**
	 * Move the jumper towards its direction, by the given count.
	 * @param count, int
     *      it has three conditions:
     *      count = 1, move to the cell that is in front of the jumper.
     *      count = 2, move to the cell that is two cells in front of the jumper.
     *      otherwise, remove the jumper from grid.
	 */
	public void move(int count) {
		Grid<Actor> grid = getGrid();
		if (grid == null)
			return;
		Location loc = getLocation();
		Location next = loc.getAdjacentLocation(getDirection());
        // get the cell that is two cells in front of the jumper
        Location nextAgain = next.getAdjacentLocation(getDirection());
        
		if (count == 2 && grid.isValid(nextAgain)) {
            moveTo(nextAgain);
		} else if (count == 1 && grid.isValid(next)) {
			moveTo(next);
		} else {
			removeSelfFromGrid();
		}

	}

	/**
	 * Decide whether the jumper can move or how many cells can jump
	 * 
	 * @return it has 4 conditions:
     *           return -1, indicate that the grid of an actor doesn't exist.
	 *           return 0, indicate that it has other actor except flower in 
	 *                 front of jumper, the jumper will turn at next time.
	 *           return 1, indicate that it has actor except flower in the cell
     *                 that in two cells in fronts of jumper but it has none
     *                 thing or only has a flower in front of the jumper.
     *           return 2, indicate that is has nothing or only has a flower in
     *                      two cells front of the jumper.              
	 */
	public int canMove() {
		Grid<Actor> grid = getGrid();
		if (grid == null)
			return -1;
		Location loc = getLocation();
		Location next = loc.getAdjacentLocation(getDirection());
		Location nextAgain = next.getAdjacentLocation(getDirection());

        // determine whether the jumper can jump to the cell
        //   which in two cells front of jumper 
		if (grid.isValid(nextAgain)) {
			Actor neighbor = grid.get(nextAgain);
			if ((neighbor == null) || (neighbor instanceof Flower))
				return 2;
		}

        // determine whether the jumper can jump to the cell which
        //    is in front of jumper.
		if (grid.isValid(next)) {
			Actor neighbor = grid.get(next);
			if ((neighbor == null) || (neighbor instanceof Flower))
				return 1;
		}

		return 0;
	}

}
