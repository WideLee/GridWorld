/**
 * 
 */
package test;

import static org.junit.Assert.*;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import org.junit.Before;
import org.junit.Test;

/**
 * @author limkuan
 * 
 */
public class TestJumper {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * 如果整个Grid只有一个Jumper， 
	 * 测试是否能够正确往前条两个格子
	 */
	@Test
	public void testAct_1() {

		Grid<Actor> grid = new BoundedGrid<>(20, 20);
		Jumper bob = new Jumper();
		bob.setDirection(Location.SOUTH);
		bob.putSelfInGrid(grid, new Location(2, 2));
		bob.act();
		assertEquals(bob.getLocation(), new Location(4, 2));

	}

	/**
	 * 测试当Jumper的前面的第二块是Flower时，
	 * 是否会按照要求跳到flower上； 
	 * 当前面的第二块是石头时，是否会按照要求前进一块
	 */
	@Test
	public void testAct_2() {

		Grid<Actor> grid = new BoundedGrid<>(20, 20);
		Jumper bob = new Jumper();
		bob.setDirection(Location.SOUTH);
		bob.putSelfInGrid(grid, new Location(2, 2));

		Jumper alice = new Jumper();
		alice.setDirection(Location.SOUTH);
		alice.putSelfInGrid(grid, new Location(2, 3));

		Flower flower = new Flower();
		flower.putSelfInGrid(grid, new Location(4, 2));

		Rock rock = new Rock();
		rock.putSelfInGrid(grid, new Location(4, 3));

		bob.act();
		alice.act();

		assertEquals(bob.getLocation(), new Location(4, 2));
		assertEquals(alice.getLocation(), new Location(3, 3));
	}

	/**
	 * 当前面的第二块是在grid外部时，是否会前进一块； 
	 * 当前面是grid的边缘时，是否会转向
	 */
	@Test
	public void testAct_3() {
		Grid<Actor> grid = new BoundedGrid<Actor>(20, 20);

		Jumper bob = new Jumper();

		bob.setDirection(Location.NORTH);
		bob.putSelfInGrid(grid, new Location(1, 2));
		Jumper alice = new Jumper();

		alice.setDirection(Location.NORTH);
		alice.putSelfInGrid(grid, new Location(0, 3));

		bob.act();
		alice.act();

		assertEquals(bob.getLocation(), new Location(0, 2));
		assertEquals(alice.getLocation(), new Location(0, 3));
		assertEquals(alice.getDirection(), 45);

	}

	/**
	 * 当两个Jumper相向而行， 中间隔一块时，
	 * 先动的向前移动一块，后动的跳过。
	 */
	@Test
	public void testAct_4() {

		Grid<Actor> grid = new BoundedGrid<>(20, 20);
		Jumper bob = new Jumper();
		bob.setDirection(Location.SOUTH);
		bob.putSelfInGrid(grid, new Location(2, 2));

		Jumper alice = new Jumper();
		alice.setDirection(Location.NORTH);
		alice.putSelfInGrid(grid, new Location(4, 2));

		bob.act();
		alice.act();

		assertEquals(bob.getLocation(), new Location(3, 2));
		assertEquals(alice.getLocation(), new Location(2, 2));
	}

	/**
	 * 当bug 在jumper前面时，bug向前移动一块，
	 * jumper不能跳， 只能向前移动一块；当bug在jumper的前面的第二块时，
	 * bug向前移动一块，jumper向前跳。 
	 * 此时要考虑到Bug和Jumper他们移动的先后顺序， 不同的顺序会产生不同的结果。
	 */
	@Test
	public void testAct_5() {
		Grid<Actor> grid = new BoundedGrid<>(20, 20);
		Jumper bob = new Jumper();
		bob.setDirection(Location.SOUTH);
		bob.putSelfInGrid(grid, new Location(2, 2));
		
		Jumper alice = new Jumper();
		alice.setDirection(Location.SOUTH);
		alice.putSelfInGrid(grid, new Location(3, 3));
		
		Bug buga = new Bug();
		buga.setDirection(180);
		buga.putSelfInGrid(grid, new Location(4, 2));
		
		Bug bugb = new Bug();
		bugb.setDirection(180);
		bugb.putSelfInGrid(grid, new Location(4, 3));
		
		bob.act();
		alice.act();
		buga.act();
		bugb.act();

		assertEquals(bob.getLocation(), new Location(3, 2));
		assertEquals(alice.getLocation(), new Location(5, 3));
	}
	
	/**
	 * 测试移动的函数，如果参数是2，移动到下下个相邻的位置
	 * 如果参数是1，移动到下个相邻的位置，
	 * 如果参数是0，把Jumper移除grid
	 */
	@Test
	public void testMove(){
		Grid<Actor> grid = new BoundedGrid<>(20, 20);
		Jumper bob = new Jumper();
		bob.setDirection(Location.SOUTH);
		bob.putSelfInGrid(grid, new Location(2, 1));
		
		bob.move(2);
		assertEquals(bob.getLocation(), new Location(4, 1));
		
		bob.move(1);
		assertEquals(bob.getLocation(), new Location(5, 1));
		
		bob.move(0);
		assertEquals(bob.getGrid(), null);
	}
}
