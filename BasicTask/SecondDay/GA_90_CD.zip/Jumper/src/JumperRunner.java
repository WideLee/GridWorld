/*********************************************************************
 * JumperRunner.java  Version 1.00  <Thu Jul  4 16:28:24 2013>
 * By Group 90
 * SUN YAT-SEN UNIVERSITY, GZ 510006, P. R. China
 ********************************************************************/


import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class JumperRunner {
    
	public static void main(String[] args) {
		ActorWorld world = new ActorWorld();
		world.add(new Location(3, 3), new Jumper());
		world.add(new Location(2, 3), new Rock());
		world.add(new Location(6, 8), new Bug());

		world.show();
	}
}
